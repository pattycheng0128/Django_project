from django.shortcuts import render
from .models import Product,PPhoto
# Create your views here.

def index(request):
    # 撈出資料庫裡面的資料
    products = Product.objects.all()
    return render(request, 'index.html', locals())

def detail(request, id):
    try:
        product = Product.objects.get(id=id)
        images = PPhoto.objects.filter(product=product)
    except:
        pass
    return render(request, 'detail.html', locals())