from django.shortcuts import render
from datetime import datetime
from mysite import views

# Create your views here.
def index(request, tvno = 0):
    tv_list = [ 
    {'name':'民視','tvcode':'XxJKnDLYZz4'}, 
    {'name':'台視','tvcode':'yk2CUjbyyQY'}, 
    {'name':'華視','tvcode':'TL8mmew3jb8'}
    ]
    now = datetime.now()
    hour = now.timetuple().tm_hour
    tvno = tvno
    tv = tv_list[tvno]
    return render(request, 'index.html',locals())
    # https://www.youtube.com/embed/XxJKnDLYZz4 民視
    # https://www.youtube.com/embed/yk2CUjbyyQY 台視
    # https://www.youtube.com/embed/TL8mmew3jb8 華視