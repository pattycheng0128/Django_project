from django.shortcuts import render
from mysite import models, forms
from django.shortcuts import redirect
from django.contrib.sessions.models import Session
from django.contrib import messages
from django.contrib.auth import authenticate
from django.contrib import auth
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User

# Create your views here.
def index(requset, pid=None, del_pass=None):
    # 檢查使用者是否有登入is_authenticated
    if requset.user.is_authenticated:
        username = requset.user.username
    messages.get_messages(requset)
    return render(requset, 'index.html', locals())

def login(requset):
    # 不會顯示 message
    if requset.method == 'POST':
        login_form = forms.LoginForm(requset.POST)
        if login_form.is_valid():
            login_name = requset.POST['username'].strip()
            login_password = requset.POST['password']
            user = authenticate(username=login_name, password=login_password)
            if user is not None:
                if user.is_active:
                    auth.login(requset, user)
                    messages.add_message(requset, messages.SUCCESS, '登入成功')
                    return redirect("/")
                else:
                    messages.add_message(requset, messages.WARNING, '帳號尚未啟用')
            else:
                messages.add_message(requset, messages.WARNING, '登入失敗')
        else:
            messages.add_message(requset, messages.INFO, '請檢查輸入的欄位內容')
    else:
        login_form = forms.LoginForm()
    return render(requset, 'login.html', locals())

def logout(request):
    auth.logout(request)
    messages.add_message(request, messages.INFO, '成功登出了')
    return redirect('/')

@login_required(login_url='/login/')
def userinfo(requset):
    if requset.user.is_authenticated:
        username = requset.user.username
        try:
            userinfo = User.objects.get(username=username)
        except:
            pass
    return render(requset, 'userinfo.html', locals())

