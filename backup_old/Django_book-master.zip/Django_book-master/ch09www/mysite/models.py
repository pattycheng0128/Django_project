from django.db import models
from django import forms

# Create your models here.
class Mood(models.Model):
    status = models.CharField(max_length=10, null=False)

    def __str__(self):
        return self.status

class Post(models.Model):
    mood = models.ForeignKey('Mood', on_delete=models.CASCADE)
    nickname = models.CharField(max_length=10,default='test')
    message = models.TextField(null=False)
    del_pass = models.CharField(max_length=10)
    pub_time = models.DateField(auto_now=True)
    enabled = models.BooleanField(default=False)

    def __str__(self):
        return self.message

class User(models.Model):
    name = models.CharField(max_length=20, null=False)
    email = models.EmailField(max_length = 254)
    password = models.CharField(max_length=20, null=False)
    enabled = models.BooleanField(default=False)

    def __str__(self):
        return self.name